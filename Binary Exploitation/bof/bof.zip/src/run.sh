#!/bin/sh

socat TCP-LISTEN:8000,reuseaddr,fork,nodelay,su=ctf EXEC:'./chall'
